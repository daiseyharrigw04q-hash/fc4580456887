// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("macos x86 64\n", stdout);
  return lionss_run_workload("macos-x86-64");
}
