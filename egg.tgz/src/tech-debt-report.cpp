// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("tech debt report"); }
int main(){
  announce();
  return lionss_run_workload("tech-debt-report");
}
